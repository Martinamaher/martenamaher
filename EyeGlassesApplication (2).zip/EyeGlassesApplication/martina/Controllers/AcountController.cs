﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

public class AccountController : Controller
{
	private readonly IHttpClientFactory _httpClientFactory;

	public AccountController(IHttpClientFactory httpClientFactory)
	{
		_httpClientFactory = httpClientFactory;
	}

	// GET: /Account/Register
	public IActionResult Register()
	{
		return View();
	}

	// POST: /Account/Register
	[HttpPost]
	public async Task<IActionResult> Register(RegisterViewModel model)
	{
		if (!ModelState.IsValid)
			return View(model);

		var client = _httpClientFactory.CreateClient();

		var json = JsonConvert.SerializeObject(new
		{
			username = model.Username,
			email = model.Email,
			password = model.Password
		});

		var data = new StringContent(json, Encoding.UTF8, "application/json");

		var response = await client.PostAsync("http://localhost:5000/api/auth/register", data);

		if (response.IsSuccessStatusCode)
		{
			TempData["Success"] = "تم التسجيل بنجاح! يمكنك تسجيل الدخول الآن.";
			return RedirectToAction("Login");
		}
		else
		{
			var error = await response.Content.ReadAsStringAsync();
			ModelState.AddModelError("", error);
			return View(model);
		}
	}

	// GET: /Account/Login
	public IActionResult Login()
	{
		return View();
	}

	// بعد تسجيل الدخول بنجاح، يمكن التوجه إلى Dashboard
	public IActionResult Dashboard()
	{
		return View();
	}
}
