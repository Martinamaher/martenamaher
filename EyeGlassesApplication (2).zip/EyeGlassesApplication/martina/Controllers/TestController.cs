﻿using EyeGlassesApplication.Data;
using Microsoft.AspNetCore.Mvc;
using System;

[ApiController]
[Route("api/[controller]")]
public class TestController : ControllerBase
{
	private readonly ApplicationDbContext _context;

	public TestController(ApplicationDbContext context)
	{
		_context = context;
	}

	[HttpGet("products")]
	public IActionResult GetProducts()
	{
		var products = _context.Products.ToList();
		return Ok(products);
	}
}