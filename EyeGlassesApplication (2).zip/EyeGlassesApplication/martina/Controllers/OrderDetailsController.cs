﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EyeGlassesApplication.Data;
using EyeGlassesApplication.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace EyeGlassesApplication.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class OrderDetailsController : ControllerBase
	{
		private readonly ApplicationDbContext _context;

		public OrderDetailsController(ApplicationDbContext context)
		{
			_context = context;
		}

		// GET: api/OrderDetails
		[HttpGet]
		public async Task<ActionResult<IEnumerable<Order_Details>>> GetOrderDetails()
		{
			return await _context.Order_Details
				.Include(od => od.Order)
				.Include(od => od.Product)
				.ToListAsync();
		}

		// GET: api/OrderDetails/5
		[HttpGet("{id}")]
		public async Task<ActionResult<Order_Details>> GetOrderDetail(int id)
		{
			var detail = await _context.Order_Details
				.Include(od => od.Order)
				.Include(od => od.Product)
				.FirstOrDefaultAsync(od => od.OrderDetailsID == id);

			if (detail == null)
				return NotFound();

			return detail;
		}

		// POST: api/OrderDetails
		[HttpPost]
		public async Task<ActionResult<Order_Details>> PostOrderDetail(Order_Details orderDetail)
		{
			_context.Order_Details.Add(orderDetail);
			await _context.SaveChangesAsync();

			return CreatedAtAction(nameof(GetOrderDetail), new { id = orderDetail.OrderDetailsID }, orderDetail);
		}

		// PUT: api/OrderDetails/5
		[HttpPut("{id}")]
		public async Task<IActionResult> PutOrderDetail(int id, Order_Details orderDetail)
		{
			if (id != orderDetail.OrderDetailsID)
				return BadRequest();

			_context.Entry(orderDetail).State = EntityState.Modified;

			try
			{
				await _context.SaveChangesAsync();
			}
			catch (DbUpdateConcurrencyException)
			{
				if (!OrderDetailExists(id))
					return NotFound();
				else
					throw;
			}

			return NoContent();
		}

		// DELETE: api/OrderDetails/5
		[HttpDelete("{id}")]
		public async Task<IActionResult> DeleteOrderDetail(int id)
		{
			var detail = await _context.Order_Details.FindAsync(id);
			if (detail == null)
				return NotFound();

			_context.Order_Details.Remove(detail);
			await _context.SaveChangesAsync();

			return NoContent();
		}

		private bool OrderDetailExists(int id)
		{
			return _context.Order_Details.Any(e => e.OrderDetailsID == id);
		}
	}
}
