﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EyeGlassesApplication.Data;
using EyeGlassesApplication.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EyeGlassesApplication.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class LenseCompanyController : ControllerBase
	{
		private readonly ApplicationDbContext _context;

		public LenseCompanyController(ApplicationDbContext context)
		{
			_context = context;
		}

		// GET: api/LenseCompany
		[HttpGet]
		public async Task<ActionResult<IEnumerable<LenseCompany>>> GetLenseCompanies()
		{
			return await _context.LenseCompanies.ToListAsync();
		}

		// GET: api/LenseCompany/5
		[HttpGet("{id}")]
		public async Task<ActionResult<LenseCompany>> GetLenseCompany(int id)
		{
			var lenseCompany = await _context.LenseCompanies.FindAsync(id);

			if (lenseCompany == null)
				return NotFound();

			return lenseCompany;
		}

		// POST: api/LenseCompany
		[HttpPost]
		public async Task<ActionResult<LenseCompany>> PostLenseCompany(LenseCompany lenseCompany)
		{
			_context.LenseCompanies.Add(lenseCompany);
			await _context.SaveChangesAsync();

			return CreatedAtAction(nameof(GetLenseCompany), new { id = lenseCompany.LenseCompanyID }, lenseCompany);
		}

		// PUT: api/LenseCompany/5
		[HttpPut("{id}")]
		public async Task<IActionResult> PutLenseCompany(int id, LenseCompany lenseCompany)
		{
			if (id != lenseCompany.LenseCompanyID)
				return BadRequest();

			_context.Entry(lenseCompany).State = EntityState.Modified;

			try
			{
				await _context.SaveChangesAsync();
			}
			catch (DbUpdateConcurrencyException)
			{
				if (!LenseCompanyExists(id))
					return NotFound();
				else
					throw;
			}

			return NoContent();
		}

		// DELETE: api/LenseCompany/5
		[HttpDelete("{id}")]
		public async Task<IActionResult> DeleteLenseCompany(int id)
		{
			var lenseCompany = await _context.LenseCompanies.FindAsync(id);
			if (lenseCompany == null)
				return NotFound();

			_context.LenseCompanies.Remove(lenseCompany);
			await _context.SaveChangesAsync();

			return NoContent();
		}

		private bool LenseCompanyExists(int id)
		{
			return _context.LenseCompanies.Any(e => e.LenseCompanyID == id);
		}
	}
}
