﻿using EyeGlassesApplication.Data;
using EyeGlassesApplication.Models;
using eyeglassesstoreapp.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EyeGlassesApplication.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	[Authorize(Roles = "Admin")]
	public class DashboardController : ControllerBase
	{
		private readonly ApplicationDbContext _context;

		public DashboardController(ApplicationDbContext context)
		{
			_context = context;
		}

		[HttpGet("summary")]
		public async Task<ActionResult<DashboardDTO>> GetDashboardSummary()
		{
			var totalUsers = await _context.Users.CountAsync();
			var totalOrders = await _context.Orders.CountAsync();
			var totalProducts = await _context.Products.CountAsync();
			var totalRevenue = await _context.Payments.SumAsync(p => p.AmountPaid);

			// آخر 5 طلبات
			var recentOrders = await _context.Orders
	.OrderByDescending(o => o.OrderDate)
	.Take(5)
	.Include(o => o.User)
	.Include(o => o.Payments)
	.Select(o => new RecentOrderDTO
	{
		OrderId = o.OrderID,
		CustomerName = o.User.FirstName,
		OrderDate = o.OrderDate,
		OrderTotal = o.Payments.Sum(p => (decimal?)p.AmountPaid) ?? 0
	})
	.ToListAsync();

			// المنتج الأعلى مبيعًا
			var topProduct = await _context.Order_Details
				.GroupBy(od => od.ProductID)
				.Select(g => new
				{
					ProductId = g.Key,
					TotalQuantity = g.Sum(x => x.Quantity)
				})
				.OrderByDescending(x => x.TotalQuantity)
				.FirstOrDefaultAsync();

			string topProductName = "N/A";
			int topProductSales = 0;

			if (topProduct != null)
			{
				var product = await _context.Products
					.FirstOrDefaultAsync(p => p.ProductID == topProduct.ProductId);
				if (product != null)
				{
					topProductName = product.ProductName;
					topProductSales = topProduct.TotalQuantity;
				}
			}

			var dashboard = new DashboardDTO
			{
				TotalUsers = totalUsers,
				TotalOrders = totalOrders,
				TotalProducts = totalProducts,
				TotalRevenue = totalRevenue,
				RecentOrders = recentOrders,
				TopProductName = topProductName,
				TopProductSales = topProductSales
			};

			return Ok(dashboard);
		}
	}
}
