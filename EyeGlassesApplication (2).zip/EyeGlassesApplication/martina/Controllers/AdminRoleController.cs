﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EyeGlassesApplication.Data;
using EyeGlassesApplication.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EyeGlassesApplication.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class AdminRoleController : ControllerBase
	{
		private readonly ApplicationDbContext _context;

		public AdminRoleController(ApplicationDbContext context)
		{
			_context = context;
		}

		// GET: api/AdminRole
		[HttpGet]
		public async Task<ActionResult<IEnumerable<AdminRole>>> GetAdminRoles()
		{
			return await _context.AdminRoles.ToListAsync();
		}

		// GET: api/AdminRole/5
		[HttpGet("{id}")]
		public async Task<ActionResult<AdminRole>> GetAdminRole(int id)
		{
			var adminRole = await _context.AdminRoles.FindAsync(id);

			if (adminRole == null)
				return NotFound();

			return adminRole;
		}

		// POST: api/AdminRole
		[HttpPost]
		public async Task<ActionResult<AdminRole>> PostAdminRole(AdminRole adminRole)
		{
			_context.AdminRoles.Add(adminRole);
			await _context.SaveChangesAsync();

			return CreatedAtAction(nameof(GetAdminRole), new { id = adminRole.AdminRoleID }, adminRole);
		}

		// PUT: api/AdminRole/5
		[HttpPut("{id}")]
		public async Task<IActionResult> PutAdminRole(int id, AdminRole adminRole)
		{
			if (id != adminRole.AdminRoleID)
				return BadRequest();

			_context.Entry(adminRole).State = EntityState.Modified;

			try
			{
				await _context.SaveChangesAsync();
			}
			catch (DbUpdateConcurrencyException)
			{
				if (!AdminRoleExists(id))
					return NotFound();
				else
					throw;
			}

			return NoContent();
		}

		// DELETE: api/AdminRole/5
		[HttpDelete("{id}")]
		public async Task<IActionResult> DeleteAdminRole(int id)
		{
			var adminRole = await _context.AdminRoles.FindAsync(id);
			if (adminRole == null)
				return NotFound();

			_context.AdminRoles.Remove(adminRole);
			await _context.SaveChangesAsync();

			return NoContent();
		}

		private bool AdminRoleExists(int id)
		{
			return _context.AdminRoles.Any(e => e.AdminRoleID == id);
		}
	}
}
