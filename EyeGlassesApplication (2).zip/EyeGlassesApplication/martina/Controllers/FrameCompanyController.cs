﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EyeGlassesApplication.Data;
using EyeGlassesApplication.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EyeGlassesApplication.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class FrameCompanyController : ControllerBase
	{
		private readonly ApplicationDbContext _context;

		public FrameCompanyController(ApplicationDbContext context)
		{
			_context = context;
		}

		// GET: api/FrameCompany
		[HttpGet]
		public async Task<ActionResult<IEnumerable<FrameCompany>>> GetFrameCompanies()
		{
			return await _context.FrameCompanies.ToListAsync();
		}

		// GET: api/FrameCompany/5
		[HttpGet("{id}")]
		public async Task<ActionResult<FrameCompany>> GetFrameCompany(int id)
		{
			var frameCompany = await _context.FrameCompanies.FindAsync(id);

			if (frameCompany == null)
				return NotFound();

			return frameCompany;
		}

		// POST: api/FrameCompany
		[HttpPost]
		public async Task<ActionResult<FrameCompany>> PostFrameCompany(FrameCompany frameCompany)
		{
			_context.FrameCompanies.Add(frameCompany);
			await _context.SaveChangesAsync();

			return CreatedAtAction(nameof(GetFrameCompany), new { id = frameCompany.FrameCompanyID }, frameCompany);
		}

		// PUT: api/FrameCompany/5
		[HttpPut("{id}")]
		public async Task<IActionResult> PutFrameCompany(int id, FrameCompany frameCompany)
		{
			if (id != frameCompany.FrameCompanyID)
				return BadRequest();

			_context.Entry(frameCompany).State = EntityState.Modified;

			try
			{
				await _context.SaveChangesAsync();
			}
			catch (DbUpdateConcurrencyException)
			{
				if (!FrameCompanyExists(id))
					return NotFound();
				else
					throw;
			}

			return NoContent();
		}

		// DELETE: api/FrameCompany/5
		[HttpDelete("{id}")]
		public async Task<IActionResult> DeleteFrameCompany(int id)
		{
			var frameCompany = await _context.FrameCompanies.FindAsync(id);
			if (frameCompany == null)
				return NotFound();

			_context.FrameCompanies.Remove(frameCompany);
			await _context.SaveChangesAsync();

			return NoContent();
		}

		private bool FrameCompanyExists(int id)
		{
			return _context.FrameCompanies.Any(e => e.FrameCompanyID == id);
		}
	}
}
