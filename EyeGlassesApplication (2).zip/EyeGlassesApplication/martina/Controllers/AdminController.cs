﻿using EyeGlassesApplication.Data;
using EyeGlassesApplication.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace EyeGlassesApplication.Controllers
{
	public class AdminController : Controller
	{
		private readonly ApplicationDbContext _context;

		// الـ Constructor: لتهيئة الاتصال بقاعدة البيانات
		public AdminController(ApplicationDbContext context)
		{
			_context = context;
		}

		// GET: Admin
		public async Task<IActionResult> Index()
		{
			// الحصول على جميع المدراء من قاعدة البيانات
			var admins = await _context.Admins.ToListAsync();
			return View(admins); // عرضهم في الـ View
		}

		// GET: Admin/Details/5
		public async Task<IActionResult> Details(int? id)
		{
			if (id == null)
			{
				return NotFound(); // في حالة عدم وجود ID
			}

			// البحث عن المدير بناءً على الـ ID
			var admin = await _context.Admins
				.FirstOrDefaultAsync(m => m.AdminID == id);
			if (admin == null)
			{
				return NotFound(); // في حالة عدم وجود المدير في قاعدة البيانات
			}

			return View(admin); // عرض تفاصيل المدير في الـ View
		}

		// GET: Admin/Create
		public IActionResult Create()
		{
			return View(); // عرض صفحة إنشاء مدير جديد
		}

		// POST: Admin/Create
		[HttpPost]
		[ValidateAntiForgeryToken] // للتحقق من أن الطلب جاء من الصفحة نفسها
		public async Task<IActionResult> Create([Bind("AdminID,AdminName,Email,Password,PhoneNumber,DateOfBirth,DateCreated,IsActive")] Admin admin)
		{
			if (ModelState.IsValid)
			{
				// إضافة المدير إلى قاعدة البيانات
				_context.Add(admin);
				await _context.SaveChangesAsync();
				return RedirectToAction(nameof(Index)); // العودة إلى صفحة عرض كل المدراء
			}
			return View(admin); // إذا كانت البيانات غير صحيحة، عرضها مرة أخرى في الـ View
		}

		// GET: Admin/Edit/5
		public async Task<IActionResult> Edit(int? id)
		{
			if (id == null)
			{
				return NotFound(); // في حالة عدم وجود ID
			}

			var admin = await _context.Admins.FindAsync(id);
			if (admin == null)
			{
				return NotFound(); // في حالة عدم وجود المدير في قاعدة البيانات
			}

			return View(admin); // عرض صفحة تعديل المدير
		}

		// POST: Admin/Edit/5
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Edit(int id, [Bind("AdminID,AdminName,Email,Password,PhoneNumber,DateOfBirth,DateCreated,IsActive")] Admin admin)
		{
			if (id != admin.AdminID)
			{
				return NotFound(); // إذا لم يتطابق الـ ID
			}

			if (ModelState.IsValid)
			{
				try
				{
					_context.Update(admin); // تعديل البيانات في قاعدة البيانات
					await _context.SaveChangesAsync();
				}
				catch (DbUpdateConcurrencyException)
				{
					if (!AdminExists(admin.AdminID))
					{
						return NotFound(); // في حالة عدم وجود المدير
					}
					else
					{
						throw;
					}
				}
				return RedirectToAction(nameof(Index)); // العودة إلى صفحة عرض المدراء
			}
			return View(admin); // في حالة وجود خطأ، عرض الـ View مرة أخرى
		}

		// GET: Admin/Delete/5
		public async Task<IActionResult> Delete(int? id)
		{
			if (id == null)
			{
				return NotFound(); // في حالة عدم وجود ID
			}

			var admin = await _context.Admins
				.FirstOrDefaultAsync(m => m.AdminID == id);
			if (admin == null)
			{
				return NotFound(); // في حالة عدم وجود المدير
			}

			return View(admin); // عرض صفحة التأكيد على الحذف
		}

		// POST: Admin/Delete/5
		[HttpPost, ActionName("Delete")]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> DeleteConfirmed(int id)
		{
			var admin = await _context.Admins.FindAsync(id);
			if (admin != null)
			{
				_context.Admins.Remove(admin); // حذف المدير من قاعدة البيانات
				await _context.SaveChangesAsync();
			}
			return RedirectToAction(nameof(Index)); // العودة إلى صفحة عرض كل المدراء بعد الحذف
		}

		// التحقق من وجود المدير في قاعدة البيانات
		private bool AdminExists(int id)
		{
			return _context.Admins.Any(e => e.AdminID == id);
		}
	}
}
